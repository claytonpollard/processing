This artwork is titled "Explosions"

To use it:
 - Click and drag the mouse
 - Release to create a fuse
 - The longer the fuse: the bigger the explosion